#Isaac Escobar
# 27 June 2026
# P4LAB1
# This program creates a square and triangle using turtle graphics.


import turtle

# Screen setup
wn = turtle.Screen()
wn.bgcolor("lightblue")

# Turtle setup
t = turtle.Turtle()
t.pensize(3)
t.pencolor("brown")
t.speed(3)

# -------------------
# DRAW SQUARE (base)
# -------------------
for i in range(4):
    t.forward(150)
    t.left(90)

# -------------------
# MOVE TO ROOF START
# -------------------
t.penup()
t.left(90)
t.forward(150)   # go to top of square
t.right(90)
t.pendown()

# Change color for roof
t.pencolor("red")

# -------------------
# DRAW TRIANGLE (roof)
# -------------------
count = 0
while count < 3:
    t.forward(150)
    t.left(120)
    count += 1

# Finish
t.hideturtle()
wn.mainloop()